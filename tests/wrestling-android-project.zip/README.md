# لعبة المصارعة — Android wrapper

مشروع Android Studio يغلّف لعبة Three.js الأصلية داخل WebView محلي. يتضمن ملفات اللعبة الأصلية والشخصيات والحركات، ويضيف أزرار لمس مناسبة للهاتف.

## بناء APK
- افتح المشروع في Android Studio ثم نفّذ `assembleDebug`، أو
- ارفع المشروع إلى GitHub ثم شغّل GitHub Actions باسم **Build Wrestling APK**. سيظهر `app-debug.apk` كـ Artifact بعد نجاح البناء.

الحزمة: `com.massoudstyle.wrestling` — اتجاه أفقي — الحد الأدنى Android 6.0.
