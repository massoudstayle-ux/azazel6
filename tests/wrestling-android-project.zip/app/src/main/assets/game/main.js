import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';

// ==================== data ====================
const MOVE_KEYS = ['Bodyslam','AlabamaSlam','BTPowerbomb','BodySlamRev','BodyslamToss','Brainbuster','Chokeslam','Codebreaker'];
const MOVE_INFO = {
  Bodyslam:     { ar:'بودي سلام',      dmg:10 },
  AlabamaSlam:  { ar:'ألاباما سلام',   dmg:16 },
  BTPowerbomb:  { ar:'باور بومب',      dmg:18 },
  BodySlamRev:  { ar:'بودي سلام معاكس', dmg:12 },
  BodyslamToss: { ar:'رمية بودي سلام',  dmg:10 },
  Brainbuster:  { ar:'برين باستر',     dmg:20 },
  Chokeslam:    { ar:'تشوك سلام',      dmg:22 },
  Codebreaker:  { ar:'كود بريكر',      dmg:15 },
};
const CHARS = {
  orton: { glb:'./assets/orton.glb', label:'أورتون', hipY:117.441 },
  aj:    { glb:'./assets/aj.glb',    label:'إي جي',  hipY:119.494 },
};
const TARGET_H = 1.8;      // fighters ~1.8 m tall
const RING_R = 6.0;
const MOVE_RANGE = 2.8;    // max distance to initiate a grapple
const UI = id => document.getElementById(id);

const clipsData = await (await fetch('./assets/clips.json')).json();
const staging   = await (await fetch('./assets/staging.json')).json();

// ==================== renderer / scene ====================
const renderer = new THREE.WebGLRenderer({ canvas: UI('c'), antialias:true });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.setSize(innerWidth, innerHeight);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x05060a);
scene.fog = new THREE.Fog(0x05060a, 20, 60);

const camera = new THREE.PerspectiveCamera(55, innerWidth/innerHeight, 0.1, 200);
camera.position.set(0, 4.5, 9.5);

addEventListener('resize', () => {
  camera.aspect = innerWidth/innerHeight; camera.updateProjectionMatrix();
  renderer.setSize(innerWidth, innerHeight);
});

scene.add(new THREE.HemisphereLight(0x8899bb, 0x080810, 1.0));
const spot = new THREE.SpotLight(0xfff2d0, 1200, 45, Math.PI/4.5, 0.45, 1.4);
spot.position.set(0, 15, 0); spot.castShadow = true;
spot.shadow.mapSize.set(2048, 2048);
scene.add(spot, spot.target);
const rim1 = new THREE.SpotLight(0xff5544, 300, 45, Math.PI/5, 0.6, 1.5); rim1.position.set(-10, 9, -7); scene.add(rim1);
const rim2 = new THREE.SpotLight(0x4488ff, 300, 45, Math.PI/5, 0.6, 1.5); rim2.position.set(10, 9, -7);  scene.add(rim2);

// ==================== the ring ====================
function buildRing(){
  const g = new THREE.Group();
  const cv = document.createElement('canvas'); cv.width = cv.height = 512;
  const ctx = cv.getContext('2d');
  ctx.fillStyle = '#8e2434'; ctx.fillRect(0,0,512,512);
  ctx.strokeStyle = '#e8d9b5'; ctx.lineWidth = 10; ctx.strokeRect(24,24,464,464);
  ctx.font = 'bold 84px Arial'; ctx.fillStyle = '#e8d9b5';
  ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.fillText('AAWX', 256, 256);
  const tex = new THREE.CanvasTexture(cv); tex.colorSpace = THREE.SRGBColorSpace;

  const floor = new THREE.Mesh(new THREE.CircleGeometry(RING_R, 64),
    new THREE.MeshStandardMaterial({ map:tex, roughness:0.9 }));
  floor.rotation.x = -Math.PI/2; floor.receiveShadow = true; g.add(floor);

  const apron = new THREE.Mesh(new THREE.CylinderGeometry(RING_R, RING_R+0.55, 0.55, 64),
    new THREE.MeshStandardMaterial({ color:0x14161c, roughness:0.6 }));
  apron.position.y = -0.28; g.add(apron);

  const postMat = new THREE.MeshStandardMaterial({ color:0xcfd8dc, metalness:0.7, roughness:0.3 });
  for (let i=0;i<4;i++){
    const a = i*Math.PI/2 + Math.PI/4;
    const post = new THREE.Mesh(new THREE.CylinderGeometry(0.07,0.07,1.75,12), postMat);
    post.position.set(Math.cos(a)*RING_R, 0.87, Math.sin(a)*RING_R);
    post.castShadow = true; g.add(post);
  }
  const ropeMats = [0xdddddd, 0xdd2222, 0xdddddd].map(c => new THREE.MeshStandardMaterial({ color:c, roughness:0.5 }));
  for (let r=0;r<3;r++){
    const y = 0.55 + r*0.45;
    for (let i=0;i<4;i++){
      const a1 = i*Math.PI/2 + Math.PI/4, a2 = (i+1)*Math.PI/2 + Math.PI/4;
      const p1 = new THREE.Vector3(Math.cos(a1)*RING_R, y, Math.sin(a1)*RING_R);
      const p2 = new THREE.Vector3(Math.cos(a2)*RING_R, y, Math.sin(a2)*RING_R);
      const rope = new THREE.Mesh(new THREE.CylinderGeometry(0.03,0.03,p1.distanceTo(p2),8), ropeMats[r]);
      rope.position.copy(p1).add(p2).multiplyScalar(0.5);
      rope.lookAt(p2); rope.rotateX(Math.PI/2); g.add(rope);
    }
  }
  const ground = new THREE.Mesh(new THREE.CircleGeometry(60, 48),
    new THREE.MeshStandardMaterial({ color:0x0b0d13, roughness:1 }));
  ground.rotation.x = -Math.PI/2; ground.position.y = -0.57; ground.receiveShadow = true;
  g.add(ground);
  return g;
}
scene.add(buildRing());

// ==================== baked clip helpers ====================
function toTrack(bone, d, kind){
  const C = kind==='p' ? THREE.VectorKeyframeTrack : THREE.QuaternionKeyframeTrack;
  return new C(bone + '.' + (kind==='p'?'position':'quaternion'),
    new Float32Array(d.t), new Float32Array(d[kind]));
}
function bakedClip(charKey, move, slot){
  const d = clipsData[charKey][move][slot];
  const tracks = [];
  for (const [bone, td] of Object.entries(d.tracks)){
    if (bone === 'rootx'){ tracks.push(toTrack(bone, td, 'p')); tracks.push(toTrack(bone, td, 'q')); }
    else tracks.push(toTrack(bone, td, 'q'));
  }
  return new THREE.AnimationClip(move+'_'+slot, d.dur, tracks);
}
function sampleHipXZ(d, t){
  const T = d.tracks.rootx.t, P = d.tracks.rootx.p;
  if (t <= T[0]) return [P[0], P[2]];
  const last = T.length-1;
  if (t >= T[last]) return [P[last*3], P[last*3+2]];
  let i=0; while (T[i+1] < t) i++;
  const f = (t-T[i]) / (T[i+1]-T[i] || 1e-6);
  return [P[i*3]+(P[i*3+3]-P[i*3])*f, P[i*3+2]+(P[i*3+5]-P[i*3+2])*f];
}
const hipData = {};
for (const ck of Object.keys(clipsData))
  for (const m of MOVE_KEYS)
    for (const s of ['main','receiver'])
      hipData[ck+m+s] = clipsData[ck][m][s];

// ==================== input ====================
const keys = {};
addEventListener('keydown', e => {
  keys[e.code] = true;
  if (['Space','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.code)) e.preventDefault();
});
addEventListener('keyup', e => keys[e.code] = false);

// ==================== fighter ====================
class Fighter {
  constructor(charKey, gltf){
    this.key = charKey;
    this.label = CHARS[charKey].label;
    this.root = new THREE.Group();
    this.inner = new THREE.Group();
    this.root.add(this.inner);
    this.model = gltf.scene;
    this.model.scale.setScalar(TARGET_H / CHARS[charKey].hipY);
    this.inner.add(this.model);
    // rotate so the character's built-in rest forward maps to root +Z
    this.model.updateMatrixWorld(true);
    const hip = this.model.getObjectByName('rootx');
    const toes = this.model.getObjectByName('toes_01l').getWorldPosition(new THREE.Vector3())
      .add(this.model.getObjectByName('toes_01r').getWorldPosition(new THREE.Vector3())).multiplyScalar(0.5);
    const f = toes.sub(hip.getWorldPosition(new THREE.Vector3())); f.y = 0; f.normalize();
    this.inner.rotation.y = Math.atan2(f.x, f.z);

    this.hp = 100; this.state = 'free';
    this.move = null; this.slot = null; this.moveT = 0; this.dmgDone = false; this.cool = 0;

    this.mixer = new THREE.AnimationMixer(this.model);
    const runClip = gltf.animations[0];
    // idle = first pose of the run clip held
    const idleClip = runClip.clone(); idleClip.name = 'idle';
    idleClip.tracks = idleClip.tracks.filter(t => t.name.endsWith('.quaternion')).map(t => {
      const nt = t.clone();
      nt.times = new Float32Array([0, 3]);
      const v0 = t.values.slice(0, 4);
      nt.values = new Float32Array([...v0, ...v0]);
      return nt;
    });
    idleClip.resetDuration();

    this.actions = { idle: this.mixer.clipAction(idleClip), run: this.mixer.clipAction(runClip) };
    this.actions.run.setLoop(THREE.LoopRepeat);
    for (const m of MOVE_KEYS){
      this.actions[m+'_main'] = this.mixer.clipAction(bakedClip(charKey, m, 'main'));
      this.actions[m+'_receiver'] = this.mixer.clipAction(bakedClip(charKey, m, 'receiver'));
    }
    this.actions.idle.play(); this.cur = 'idle';
    scene.add(this.root);
  }
  fade(to, speed=0.22){
    if (this.cur === to) return;
    const next = this.actions[to];
    next.reset(); next.setEffectiveWeight(1); next.play(); next.fadeIn(speed);
    if (this.actions[this.cur]) this.actions[this.cur].fadeOut(speed);
    this.cur = to;
  }
  get pos(){ return this.root.position; }
  get yaw(){ return this.root.rotation.y; }
  distTo(o){ return this.pos.distanceTo(o.pos); }
  faceToward(p){
    const d = p.clone().sub(this.pos); d.y = 0;
    if (d.lengthSq() > 1e-6) this.root.rotation.y = Math.atan2(d.x, d.z);
  }
  startMove(target, moveName){
    const st = staging[moveName];
    this.state = 'locked'; this.move = moveName; this.slot = 'main';
    this.moveT = 0; this.dmgDone = false;
    this.faceToward(target.pos);
    // receiver: place at baked start offset (rotated into attacker frame), same yaw
    const off = new THREE.Vector3(st.off0[0], st.off0[1], st.off0[2]);
    off.applyAxisAngle(new THREE.Vector3(0,1,0), this.yaw);
    target.startReceive(this, moveName, off);
    this.fade(moveName+'_main', 0.12);
    showMoveName(MOVE_INFO[moveName].ar);
  }
  startReceive(attacker, moveName, offset){
    this.state = 'locked'; this.move = moveName; this.slot = 'receiver';
    this.moveT = 0; this.dmgDone = false;
    this.pos.copy(attacker.pos).add(offset);
    this.root.rotation.y = attacker.yaw;
    this.fade(moveName+'_receiver', 0.12);
  }
  advanceMoveRootMotion(dt){
    // convert baked hip local XZ motion into world root motion
    const d = hipData[this.key + this.move + this.slot];
    const t0 = this.moveT, t1 = this.moveT + dt;
    const [x0, z0] = sampleHipXZ(d, t0);
    const [x1, z1] = sampleHipXZ(d, t1);
    const dx = x1-x0, dz = z1-z0;
    const sin = Math.sin(this.yaw), cos = Math.cos(this.yaw);
    this.pos.x += dx*cos + dz*sin;
    this.pos.z += -dx*sin + dz*cos;
    this.moveT = t1;
    // clamp inside ring
    const r = Math.hypot(this.pos.x, this.pos.z);
    if (r > RING_R-0.3){ const k = (RING_R-0.3)/r; this.pos.x*=k; this.pos.z*=k; }
    // damage moment = receiver's lowest hip height
    if (!this.dmgDone && this.slot === 'main'){
      const st = staging[this.move];
      if (t1 >= st.tStar){
        this.dmgDone = true;
        targetFighterOf(this).hp = Math.max(0, targetFighterOf(this).hp - MOVE_INFO[this.move].dmg);
        updateHP(); flash(); shake = 0.5;
        if (targetFighterOf(this).hp <= 0) endMatch(this);
      }
    }
    const dur = this.slot==='main' ? staging[this.move].dur : staging[this.move].durR;
    if (t1 >= dur){
      this.state = 'free'; this.move = null; this.slot = null; this.cool = 0.9;
      this.fade('idle');
    }
  }
  update(dt, input){
    this.cool = Math.max(0, this.cool - dt);
    if (this.state === 'locked'){ this.advanceMoveRootMotion(dt); return; }
    // free movement
    let mx = 0, mz = 0;
    if (input.up) mz -= 1; if (input.down) mz += 1;
    if (input.left) mx -= 1; if (input.right) mx += 1;
    const moving = (mx || mz);
    if (moving){
      const L = Math.hypot(mx, mz); mx/=L; mz/=L;
      // move relative to camera (camera looks down -Z mostly): use world axes
      this.pos.x += mx*2.4*dt;
      this.pos.z += mz*2.4*dt;
      this.faceToward(new THREE.Vector3(this.pos.x + mx, 0, this.pos.z + mz));
      const r = Math.hypot(this.pos.x, this.pos.z);
      if (r > RING_R-0.3){ const k = (RING_R-0.3)/r; this.pos.x*=k; this.pos.z*=k; }
      this.fade('run');
    } else this.fade('idle');
    // attack inputs
    if (this.cool <= 0){
      let mv = null;
      if (input.random) mv = MOVE_KEYS[(Math.random()*MOVE_KEYS.length)|0];
      for (let i=0;i<8;i++) if (input.slots && input.slots[i]) mv = MOVE_KEYS[i];
      if (mv){
        const other = targetFighterOf(this);
        if (this.distTo(other) <= MOVE_RANGE && other.state === 'free'){
          this.startMove(other, mv);
        } else if (mv) {
          UI('hint').textContent = this === p1 ? 'اقترب من خصمك أولاً!' : '';
          setTimeout(()=>{ if(UI('hint').textContent.startsWith('اقترب')) UI('hint').textContent=''; }, 900);
        }
      }
    }
  }
}

// ==================== setup fighters ====================
let p1, p2, shake = 0, gameOver = false;
const targetFighterOf = f => f === p1 ? p2 : p1;

async function loadFighter(charKey){
  const loader = new GLTFLoader();
  const gltf = await loader.loadAsync(CHARS[charKey].glb);
  return new Fighter(charKey, gltf);
}

function updateHP(){
  UI('hp1').style.width = p1.hp + '%';
  UI('hp2').style.width = p2.hp + '%';
  UI('hp1t').textContent = p1.hp;
  UI('hp2t').textContent = p2.hp;
  UI('hp1').style.background = p1.hp > 35 ? 'linear-gradient(90deg,#27ae60,#2ecc71)' : 'linear-gradient(90deg,#c0392b,#e74c3c)';
  UI('hp2').style.background = p2.hp > 35 ? 'linear-gradient(-90deg,#27ae60,#2ecc71)' : 'linear-gradient(-90deg,#c0392b,#e74c3c)';
}
function flash(){
  const f = UI('flash');
  f.style.transition = 'none'; f.style.opacity = 0.55;
  requestAnimationFrame(()=>{ f.style.transition = 'opacity .35s'; f.style.opacity = 0; });
}
function showMoveName(name){
  const el = UI('moveName');
  el.textContent = name; el.style.opacity = 1;
  clearTimeout(showMoveName._t);
  showMoveName._t = setTimeout(()=> el.style.opacity = 0, 1400);
}
function endMatch(winner){
  gameOver = true;
  UI('koWinner').textContent = `الفائز: ${winner.label} 🏆`;
  UI('ko').style.display = 'flex';
}

// ==================== menu ====================
const sel = { p1:'orton', p2:'aj', mode:'cpu' };
function wirePick(rowId, key){
  UI(rowId).querySelectorAll('button').forEach(b => b.onclick = () => {
    UI(rowId).querySelectorAll('button').forEach(x => x.classList.remove('active'));
    b.classList.add('active'); sel[key] = b.dataset.v;
  });
}
wirePick('p1row','p1'); wirePick('p2row','p2'); wirePick('mrow','mode');
// avoid identical characters: if both same, auto-swap the other
UI('startBtn').onclick = async () => {
  if (sel.p1 === sel.p2) sel.p2 = sel.p1 === 'orton' ? 'aj' : 'orton';
  UI('menu').style.display = 'none';
  UI('loading').style.display = 'flex';
  [p1, p2] = await Promise.all([loadFighter(sel.p1), loadFighter(sel.p2)]);
  p1.pos.set(0, 0, 2.2); p2.pos.set(0, 0, -2.2);
  p1.root.rotation.y = Math.PI; p2.root.rotation.y = 0;
  UI('n1').textContent = p1.label + ' (لاعب 1)';
  UI('n2').textContent = sel.mode === 'cpu' ? p2.label + ' (حاسوب)' : p2.label + ' (لاعب 2)';
  updateHP();
  UI('loading').style.display = 'none';
  UI('hud').style.display = 'flex';
  UI('mobileControls').style.display = 'block';
  UI('hint').style.display = 'block';
  if (sel.mode === 'cpu') UI('hint').textContent = 'اقترب من الخصم ثم اضغط Space أو 1-8 لتنفيذ حركة';
  else UI('hint').textContent = 'لاعب1: Space/1-8 — لاعب2: Enter';
  clock.start();
  renderer.setAnimationLoop(loop);
};

// CPU AI
let aiTimer = 0;
function cpuAI(dt){
  if (gameOver || p2.state !== 'free') return;
  const d = p2.distTo(p1);
  if (d > MOVE_RANGE + 0.4){
    const dir = p1.pos.clone().sub(p2.pos); dir.y = 0; dir.normalize();
    p2.pos.addScaledVector(dir, 2.0*dt);
    p2.faceToward(p1.pos); p2.fade('run');
  } else if (p2.cool <= 0){
    p2.faceToward(p1.pos);
    if (Math.random() < 0.02 + dt*0.5){
      p2.startMove(p1, MOVE_KEYS[(Math.random()*MOVE_KEYS.length)|0]);
    } else p2.fade('idle');
  }
}

// ==================== loop ====================
const clock = new THREE.Clock();
function loop(){
  const dt = Math.min(clock.getDelta(), 0.05);
  if (!gameOver){
    p1.update(dt, {
      up: keys['KeyW'], down: keys['KeyS'], left: keys['KeyA'], right: keys['KeyD'],
      random: keys['Space'],
      slots: ['Digit1','Digit2','Digit3','Digit4','Digit5','Digit6','Digit7','Digit8'].map(k => keys[k]),
    });
    if (sel.mode === 'p2'){
      p2.update(dt, {
        up: keys['ArrowUp'], down: keys['ArrowDown'], left: keys['ArrowLeft'], right: keys['ArrowRight'],
        random: keys['Enter'], slots: [false,false,false,false,false,false,false,false],
      });
    } else cpuAI(dt);
  }
  p1.mixer.update(dt); p2.mixer.update(dt);

  // camera follows midpoint
  const mid = p1.pos.clone().add(p2.pos).multiplyScalar(0.5);
  const span = Math.max(4.5, p1.pos.distanceTo(p2.pos) * 0.85 + 3.5);
  const camTarget = new THREE.Vector3(mid.x, 2.2 + span*0.32, mid.z + span);
  camera.position.lerp(camTarget, 0.06);
  if (shake > 0){ shake = Math.max(0, shake - dt*2); camera.position.y += (Math.random()-0.5)*shake*0.35; }
  camera.lookAt(mid.x, 1.1, mid.z);

  renderer.render(scene, camera);
}


// ==================== mobile touch controls ====================
(() => {
  const stick = document.getElementById('stick');
  const knob = document.getElementById('knob');
  const mobile = document.getElementById('mobileControls');
  if (!stick || !knob || !mobile) return;
  const active = new Set();
  const release = () => { for (const k of active) keys[k] = false; active.clear(); knob.style.transform = 'translate(0px,0px)'; };
  function moveStick(e) {
    const r = stick.getBoundingClientRect();
    const cx = r.left + r.width/2, cy = r.top + r.height/2;
    let dx = e.clientX-cx, dy = e.clientY-cy;
    const max = r.width*0.34, len = Math.hypot(dx,dy);
    if (len > max) { dx = dx/len*max; dy = dy/len*max; }
    knob.style.transform = `translate(${dx}px,${dy}px)`;
    for (const k of ['KeyW','KeyA','KeyS','KeyD']) keys[k] = false;
    if (Math.abs(dx)>max*0.22) keys[dx<0?'KeyA':'KeyD'] = true;
    if (Math.abs(dy)>max*0.22) keys[dy<0?'KeyW':'KeyS'] = true;
  }
  stick.addEventListener('pointerdown', e => { stick.setPointerCapture(e.pointerId); moveStick(e); });
  stick.addEventListener('pointermove', e => { if (stick.hasPointerCapture(e.pointerId)) moveStick(e); });
  stick.addEventListener('pointerup', release); stick.addEventListener('pointercancel', release);
  document.querySelectorAll('.touchKey').forEach(btn => {
    const key = btn.dataset.key;
    btn.addEventListener('pointerdown', e => { e.preventDefault(); btn.setPointerCapture(e.pointerId); keys[key] = true; });
    const up = e => { keys[key] = false; };
    btn.addEventListener('pointerup', up); btn.addEventListener('pointercancel', up); btn.addEventListener('lostpointercapture', up);
  });
})();
